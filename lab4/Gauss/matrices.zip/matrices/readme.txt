Files contain square matrices:
- 1-st line contains positive integer N
- Then there are N lines with N floating-point values in each - matrix A of size (N x N)
- Then there is 1 line with N values - right-hand side vector f
- Then there is 1 line with N values - solution vector x to the linear problem Ax = f

There might be empty lines for better visibility, reading with "filestream >> value" will simply ignore those.
